<?php

//$lang['sot_field_heading'] = 'Field descriptions for the %s table';
