<?php

$conf['full_screen_reports']   = '1';
$conf['sot_use_lmt']           = '0';
$conf['sot_max_csv_cache_age'] = '2';
$conf['sot_super_users']       = 'admin,author';
$conf['sot_db_type']	       = 'mysql';
$conf['sot_db_host']	       = 'localhost';
$conf['sot_db_name']	       = 'sot';
$conf['sot_db_user']	       = 'sot';
$conf['sot_db_pw']		       = 'sot';

